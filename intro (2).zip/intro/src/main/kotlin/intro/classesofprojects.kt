package intro
data class Latestnews(val name: String,val description: String)

data class Features(val name: String,val description: String)
data class Dashboardoverview(val name:String,val amount:Int)