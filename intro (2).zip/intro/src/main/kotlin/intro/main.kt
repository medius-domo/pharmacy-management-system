import intro.*
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.cio.*
import io.ktor.server.engine.*
import io.ktor.server.html.*
import io.ktor.server.http.content.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlinx.html.*

fun main() {
    println("http://localhost:8080")
    embeddedServer(CIO, 8080) {
        routing {
            static("/static"){
                resources("static")}
            get("/") {
                call.respondHtml {
                    WebHead("Pharmacy Management System")
                    body {
                        NavigationBar()
                        div(classes = "hero"){
                            h1 { +"Welcome to the Pharmacy Management System" }
                            p { +"Select an option from the navigation bar to get started." }

                        }
                        div("content") {

                            div("section") {
                                h2 { +"Latest News" }
                                for (latestnews in latestnewss)
                                    Latestnewsview(latestnews) }

                            div("section") {
                                h2 { +"System Features" }
                                for (Features in FeaturesS)
                               Featuresview( Features)
                            }

                            div("section") {
                                h2 { +"Quick Links" }
                                ul {
                                    li { a(href = "/dashboard") { +"Go to Dashboard" } }
                                    li { a(href = "/inventory") { +"Manage Inventory" } }
                                    li { a(href = "/sales") { +"View Sales" } }
                                    li { a(href = "/purchasing") { +"Manage Purchasing" } }
                                    li { a(href = "/prescriptions") { +"Manage Prescriptions" } }
                                    li { a(href = "/customers") { +"Manage Customers" } }
                                    li { a(href = "/reports") { +"View Reports" } }
                                    li { a(href = "/user-management") { +"User Management" } }
                                    li { a(href = "/settings") { +"System Settings" } }
                                    li { a(href = "/help") { +"Help/Support" } }
                                }
                            }
                        }
                    }
                }
            }
            // Define routes for other pages here
            get("/dashboard") {
                call.respondHtml {
                    WebHead("Dashboard")
                    body {
                        NavigationBar()
                        div("content") {
                         div(classes = "Dashboard"){
                             h1 { +"Dashboard" }
                         }

                            // Overview Section
                            div("section") {
                                h2 { +"Overview" }
                                for (Dashboardoverview in DashboardoverviewW)
                                    Dashboardview(Dashboardoverview)
                            }

                            // Recent Activity Section
                            div("section") {
                                h2 { +"Recent Activity" }

                                h3 { +"Recent Sales" }
                                table {
                                    tr {
                                        th { +"Transaction ID" }
                                        th { +"Customer" }
                                        th { +"Amount" }
                                        th { +"Date" }
                                    }
                                    // Sample data, replace with dynamic content
                                }

                                h3 { +"Recent Purchases" }
                                table {
                                    tr {
                                        th { +"Order ID" }
                                        th { +"Supplier" }
                                        th { +"Total Amount" }
                                        th { +"Date" }
                                    }
                                    // Sample data, replace with dynamic content

                                }
                            }

                            // Sales Trends Section
                            div("section") {
                                h2 { +"Sales Trends" }
                                // Embed a chart or graph here
                                // Example: <canvas> or a library component
                                p { +"[Graphical representation of sales trends]" }
                            }

                            // Alerts Section
                            div("section") {
                                h2 { +"Alerts" }
                                ul {
                                    // Sample alerts, replace with dynamic content
                                    li { +"Product XYZ is low on stock." }
                                    li { +"Medication ABC is expired." }
                                }
                            }

                            // Quick Links Section
                            div("section") {
                                h2 { +"Quick Links" }
                                ul {
                                    li { a(href = "/inventory") { +"Manage Inventory" } }
                                    li { a(href = "/sales") { +"View Sales" } }
                                    li { a(href = "/customers") { +"Manage Customers" } }
                                    li { a(href = "/reports") { +"View Reports" } }
                                    li { a(href = "/user-management") { +"User Management" } }
                                }
                            }

                            // User Management Snapshot Section
                            div("section") {
                                h2 { +"User Management Snapshot" }
                                ul {
                                    li { +"Active Users: 50" } // Replace with dynamic data
                                    li { +"Pending Approvals: 5" } // Replace with dynamic data
                                    li { +"Security Alerts: 1" } // Replace with dynamic data
                                }
                            }

                            a(href = "/", classes = "back-to-home") { +"Back to Home" }
                        }
                    }
                }
            }

            get("/inventory") {
                call.respondHtml {
                    WebHead("Inventory Management")
                    body {
                        NavigationBar()
                        div("content") {
                            h1 { +"Inventory Management" }

                            div("section") {
                                h2 { +"Current Inventory" }
                                table {
                                    tr {
                                        th { +"Product Name" }
                                        th { +"SKU" }
                                        th { +"Category" }
                                        th { +"Quantity in Stock" }
                                        th { +"Expiration Date" }
                                        th { +"Supplier" }
                                        th { +"Actions" }
                                    }
                                    // Sample data, replace with dynamic content
                                    tr {
                                        td { +"Aspirin" }
                                        td { +"SKU123" }
                                        td { +"Pain Relief" }
                                        td { +"50" }
                                        td { +"2025-12-31" }
                                        td { +"Supplier A" }
                                        td {
                                            a(href = "#", classes = "button") { +"Update" }
                                            a(href = "#", classes = "button") { +"Delete" }
                                        }
                                    }
                                }
                            }

                            div("section") {
                                h2 { +"Add New Product" }
                                form(action = "/add-product", method = FormMethod.post) {
                                    label { +"Product Name:" }
                                    textInput(name = "product-name") { required = true }
                                    br()
                                    label { +"SKU:" }
                                    textInput(name = "sku") { required = true }
                                    br()
                                    label { +"Category:" }
                                    textInput(name = "category") { required = true }
                                    br()
                                    label { +"Supplier:" }
                                    textInput(name = "supplier") { required = true }
                                    br()
                                    label { +"Purchase Price:" }
                                    numberInput(name = "purchase-price") { required = true }
                                    br()
                                    label { +"Selling Price:" }
                                    numberInput(name = "selling-price") { required = true }
                                    br()
                                    label { +"Initial Stock Quantity:" }
                                    numberInput(name = "initial-stock") { required = true }
                                    br()
                                    submitInput(classes = "button") { value = "Add Product" }
                                }
                            }

                            div("section") {
                                h2 { +"Low Stock Alerts" }
                                ul {
                                    li { +"Product XYZ is low on stock (5 remaining)" }
                                    li { +"Product ABC is low on stock (2 remaining)" }
                                }
                            }

                            div("section") {
                                h2 { +"Search and Filter" }
                                form(action = "/search-inventory", method = FormMethod.get) {
                                    label { +"Search:" }
                                    textInput(name = "query")
                                    submitInput(classes = "button") { value = "Search" }
                                }
                                p {
                                    a(href = "/filter-category", classes = "button") { +"Filter by Category" }
                                    a(href = "/filter-supplier", classes = "button") { +"Filter by Supplier" }
                                    a(href = "/filter-low-stock", classes = "button") { +"Filter by Low Stock" }
                                }
                            }

                            a(href = "/", classes = "back-to-home") { +"Back to Home" }
                        }
                    }
                }
            }
            get("/sales") {
                call.respondHtml {
                    WebHead("Sales Management")
                    body {
                        NavigationBar()
                        div("content") {
                            h1 { +"Sales Management" }

                            div("section") {
                                h2 { +"Recent Sales Transactions" }
                                table {
                                    tr {
                                        th { +"Transaction ID" }
                                        th { +"Date" }
                                        th { +"Customer" }
                                        th { +"Total Amount" }
                                        th { +"Actions" }
                                    }
                                    // Sample data, replace with dynamic content
                                    tr {
                                        td { +"TXN001" }
                                        td { +"2024-07-10" }
                                        td { +"John Doe" }
                                        td { +"$200.00" }
                                        td {
                                            a(href = "#", classes = "button") { +"View" }
                                            a(href = "#", classes = "button") { +"Edit" }
                                        }
                                    }
                                }
                            }

                            div("section") {
                                h2 { +"Add New Sale" }
                                form(action = "/add-sale", method = FormMethod.post) {
                                    label { +"Customer Name:" }
                                    textInput(name = "customer-name") { required = true }
                                    br()
                                    label { +"Product ID:" }
                                    textInput(name = "product-id") { required = true }
                                    br()
                                    label { +"Quantity:" }
                                    numberInput(name = "quantity") { required = true }
                                    br()
                                    label { +"Total Amount:" }
                                    numberInput(name = "total-amount") { required = true }
                                    br()
                                    submitInput(classes = "button") { value = "Add Sale" }
                                }
                            }

                            div("section") {
                                h2 { +"Search Sales Records" }
                                form(action = "/search-sales", method = FormMethod.get) {
                                    label { +"Search:" }
                                    textInput(name = "query")
                                    submitInput(classes = "button") { value = "Search" }
                                }
                            }

                            div("section") {
                                h2 { +"Sales Summary" }
                                p { +"Total Sales: 100" }
                                p { +"Total Revenue: $10,000.00" }
                            }

                            div("section") {
                                h2 { +"Sales Reports" }
                                ul {
                                    li { a(href = "/daily-sales-report") { +"Daily Sales Report" } }
                                    li { a(href = "/monthly-sales-report") { +"Monthly Sales Report" } }
                                    li { a(href = "/annual-sales-report") { +"Annual Sales Report" } }
                                }
                            }

                            a(href = "/", classes = "back-to-home") { +"Back to Home" }
                        }
                    }
                }
            }
            get("/purchasing") {
                call.respondHtml {
                    WebHead("Purchasing Management")
                    body {
                        NavigationBar()
                        div("content") {
                            h1 { +"Purchasing Management" }

                            div("section") {
                                h2 { +"Current Purchase Orders" }
                                table {
                                    tr {
                                        th { +"Order ID" }
                                        th { +"Date" }
                                        th { +"Supplier" }
                                        th { +"Total Amount" }
                                        th { +"Status" }
                                        th { +"Actions" }
                                    }
                                    // Sample data, replace with dynamic content
                                    tr {
                                        td { +"PO001" }
                                        td { +"2024-07-10" }
                                        td { +"Supplier A" }
                                        td { +"$500.00" }
                                        td { +"Pending" }
                                        td {
                                            a(href = "#", classes = "button") { +"View" }
                                            a(href = "#", classes = "button") { +"Edit" }
                                        }
                                    }
                                }
                            }

                            div("section") {
                                h2 { +"Create New Purchase Order" }
                                form(action = "/add-purchase-order", method = FormMethod.post) {
                                    label { +"Supplier Name:" }
                                    textInput(name = "supplier-name") { required = true }
                                    br()
                                    label { +"Product ID:" }
                                    textInput(name = "product-id") { required = true }
                                    br()
                                    label { +"Quantity:" }
                                    numberInput(name = "quantity") { required = true }
                                    br()
                                    label { +"Total Amount:" }
                                    numberInput(name = "total-amount") { required = true }
                                    br()
                                    submitInput(classes = "button") { value = "Create Order" }
                                }
                            }

                            div("section") {
                                h2 { +"Search Purchase Orders" }
                                form(action = "/search-purchase-orders", method = FormMethod.get) {
                                    label { +"Search:" }
                                    textInput(name = "query")
                                    submitInput(classes = "button") { value = "Search" }
                                }
                            }

                            a(href = "/", classes = "back-to-home") { +"Back to Home" }
                        }
                    }
                }
            }
            get("/prescriptions") {
                call.respondHtml {
                    WebHead("Prescriptions")
                    body {
                        NavigationBar()
                        div("content") {
                            h1 { +"Prescriptions" }

                            div("section") {
                                h2 { +"Current Prescriptions" }
                                table {
                                    tr {
                                        th { +"Prescription ID" }
                                        th { +"Patient Name" }
                                        th { +"Medication" }
                                        th { +"Dosage" }
                                        th { +"Prescribing Doctor" }
                                        th { +"Actions" }
                                    }
                                    // Sample data, replace with dynamic content
                                    tr {
                                        td { +"RX001" }
                                        td { +"Jane Smith" }
                                        td { +"Medication A" }
                                        td { +"10mg" }
                                        td { +"Dr. John Doe" }
                                        td {
                                            a(href = "#", classes = "button") { +"View" }
                                            a(href = "#", classes = "button") { +"Edit" }
                                        }
                                    }
                                }
                            }

                            div("section") {
                                h2 { +"Add New Prescription" }
                                form(action = "/add-prescription", method = FormMethod.post) {
                                    label { +"Patient Name:" }
                                    textInput(name = "patient-name") { required = true }
                                    br()
                                    label { +"Medication:" }
                                    textInput(name = "medication") { required = true }
                                    br()
                                    label { +"Dosage:" }
                                    textInput(name = "dosage") { required = true }
                                    br()
                                    label { +"Prescribing Doctor:" }
                                    textInput(name = "prescribing-doctor") { required = true }
                                    br()
                                    submitInput(classes = "button") { value = "Add Prescription" }
                                }
                            }

                            div("section") {
                                h2 { +"Search Prescriptions" }
                                form(action = "/search-prescriptions", method = FormMethod.get) {
                                    label { +"Search:" }
                                    textInput(name = "query")
                                    submitInput(classes = "button") { value = "Search" }
                                }
                            }

                            div("section") {
                                h2 { +"Prescription Alerts" }
                                ul {
                                    li { +"Prescription RX002 for John Doe requires a refill." }
                                    li { +"Prescription RX003 for Mary Johnson needs a follow-up appointment." }
                                }
                            }

                            a(href = "/", classes = "back-to-home") { +"Back to Home" }
                        }
                    }
                }
            }
            get("/customers") {
                call.respondHtml {
                    WebHead("Customers")
                    body {
                        NavigationBar()
                        div("content") {
                            h1 { +"Customers" }

                            // Search and Filter
                            div("section") {
                                h2 { +"Search and Filter" }
                                form(action = "/search-customers", method = FormMethod.get) {
                                    label { +"Search:" }
                                    textInput(name = "query")
                                    submitInput(classes = "button") { value = "Search" }
                                }
                                p {
                                    a(href = "/filter-recent-purchases", classes = "button") { +"Recent Purchases" }
                                    a(href = "/filter-high-value", classes = "button") { +"High Value" }
                                }
                            }

                            // Customer List
                            div("section") {
                                h2 { +"Customer List" }
                                table {
                                    tr {
                                        th { +"Customer ID" }
                                        th { +"Name" }
                                        th { +"Contact" }
                                        th { +"Address" }
                                        th { +"Actions" }
                                    }
                                    // Sample data, replace with dynamic content
                                    tr {
                                        td { +"CUST001" }
                                        td { +"John Doe" }
                                        td { +"(555) 123-4567" }
                                        td { +"123 Main St." }
                                        td {
                                            a(href = "/customer-details?customerId=CUST001", classes = "button") { +"View" }
                                            a(href = "#", classes = "button") { +"Edit" }
                                            a(href = "#", classes = "button") { +"Delete" }
                                        }
                                    }
                                }
                            }

                            // Add New Customer
                            div("section") {
                                h2 { +"Add New Customer" }
                                form(action = "/add-customer", method = FormMethod.post) {
                                    label { +"Name:" }
                                    textInput(name = "name") { required = true }
                                    br()
                                    label { +"Contact:" }
                                    textInput(name = "contact") { required = true }
                                    br()
                                    label { +"Address:" }
                                    textInput(name = "address") { required = true }
                                    textInput(name = "address") { required = true }
                                    br()
                                    submitInput(classes = "button") { value = "Add Customer" }
                                }
                            }

                            a(href = "/", classes = "back-to-home") { +"Back to Home" }
                        }
                    }
                }
            }

            get("/reports") {
                call.respondHtml {
                    WebHead("Reports")
                    body {
                        NavigationBar()
                        div("content") {
                            h1 { +"Reports" }
                            p { +"View various reports to gain insights into pharmacy operations." }

                            div("section") {
                                h2 { +"Sales Reports" }
                                ul {
                                    li { a(href = "/daily-sales-report") { +"Daily Sales Report" } }
                                    li { a(href = "/monthly-sales-report") { +"Monthly Sales Report" } }
                                    li { a(href = "/annual-sales-report") { +"Annual Sales Report" } }
                                }
                            }

                            div("section") {
                                h2 { +"Inventory Reports" }
                                ul {
                                    li { a(href = "/current-inventory-report") { +"Current Inventory Report" } }
                                    li { a(href = "/inventory-turnover-report") { +"Inventory Turnover Report" } }
                                }
                            }

                            div("section") {
                                h2 { +"Customer Reports" }
                                ul {
                                    li { a(href = "/customer-demographics-report") { +"Customer Demographics Report" } }
                                    li { a(href = "/top-customers-report") { +"Top Customers Report" } }
                                }
                            }

                            div("section") {
                                h2 { +"Prescription Reports" }
                                ul {
                                    li { a(href = "/prescription-fill-rate-report") { +"Prescription Fill Rate Report" } }
                                    li { a(href = "/medication-utilization-report") { +"Medication Utilization Report" } }
                                }
                            }

                            div("section") {
                                h2 { +"User Activity Reports" }
                                ul {
                                    li { a(href = "/user-login-history") { +"User Login History" } }
                                    li { a(href = "/user-activity-summary") { +"User Activity Summary" } }
                                }
                            }

                            a(href = "/", classes = "back-to-home") { +"Back to Home" }
                        }
                    }
                }
            }

            get("/user-management") {
                call.respondHtml {
                    WebHead("User Management")
                    body {
                        NavigationBar()
                        div("content") {
                            h1 { +"User Management" }

                            div("section") {
                                h2 { +"Registered Users" }
                                table {
                                    tr {
                                        th { +"User ID" }
                                        th { +"Username" }
                                        th { +"Role" }
                                        th { +"Status" }
                                        th { +"Actions" }
                                    }
                                    // Sample data, replace with dynamic content
                                    tr {
                                        td { +"1" }
                                        td { +"john_doe" }
                                        td { +"Admin" }
                                        td { +"Active" }
                                        td {
                                            a(href = "#", classes = "button") { +"View" }
                                            a(href = "#", classes = "button") { +"Edit" }
                                            a(href = "#", classes = "button") { +"Delete" }
                                        }
                                    }
                                    // Add more rows as necessary
                                }
                            }

                            div("section") {
                                h2 { +"Add New User" }
                                form(action = "/add-user", method = FormMethod.post) {
                                    label { +"Username:" }
                                    textInput(name = "username") { required = true }
                                    br()
                                    label { +"Password:" }
                                    passwordInput(name = "password") { required = true }
                                    br()
                                    label { +"Role:" }
                                    select("role") {
                                        option { +"Admin" }
                                        option { +"Pharmacist" }
                                        option { +"Technician" }
                                    }
                                    br()
                                    label { +"Status:" }
                                    select("status") {
                                        option { +"Active" }
                                        option { +"Inactive" }
                                    }
                                    br()
                                    submitInput(classes = "button") { value = "Add User" }
                                }
                            }


                            div("section") {
                                h2 { +"Search Users" }
                                form(action = "/search-users", method = FormMethod.get) {
                                    label { +"Search:" }
                                    textInput(name = "query") { required = true }
                                    submitInput(classes = "button") { value = "Search" }
                                }
                            }

                            div("section") {
                                h2 { +"User Activity Logs" }
                                // Display recent activity logs (optional)
                            }

                            a(href = "/", classes = "back-to-home") { +"Back to Home" }
                        }
                    }
                }
            }

            get("/settings") {
                call.respondHtml {
                    WebHead("Settings")
                    body {
                        NavigationBar()
                        div("content") {
                            h1 { +"Settings" }

                            div("section") {
                                h2 { +"General Settings" }
                                form(action = "/update-general-settings", method = FormMethod.post) {
                                    label { +"Pharmacy Name:" }
                                    textInput(name = "pharmacy-name") { required = true }
                                    br()
                                    label { +"Contact Email:" }
                                    textInput(name = "contact-email") { required = true }
                                    br()
                                    label { +"Phone Number:" }
                                    textInput(name = "phone-number") { required = true }
                                    br()
                                    submitInput(classes = "button") { value = "Update Settings" }
                                }
                            }

                            div("section") {
                                h2 { +"Inventory Settings" }
                                form(action = "/update-inventory-settings", method = FormMethod.post) {
                                    label { +"Low Stock Alert Level:" }
                                    numberInput(name = "low-stock-level") { required = true }
                                    br()
                                    label { +"Default Supplier:" }
                                    textInput(name = "default-supplier") { required = true }
                                    br()
                                    submitInput(classes = "button") { value = "Update Inventory Settings" }
                                }
                            }

                            div("section") {
                                h2 { +"User Management Settings" }
                                form(action = "/update-user-settings", method = FormMethod.post) {
                                    label { +"Password Policy:" }
                                    textInput(name = "password-policy") { required = true }
                                    br()
                                    label { +"Session Timeout (minutes):" }
                                    numberInput(name = "session-timeout") { required = true }
                                    br()
                                    submitInput(classes = "button") { value = "Update User Settings" }
                                }
                            }

                            div("section") {
                                h2 { +"Backup and Restore" }
                                form(action = "/backup-restore", method = FormMethod.post) {
                                    submitInput(classes = "button") { value = "Backup Database" }
                                    br()
                                    label { +"Upload Backup File:" }
                                    fileInput(name = "backup-file") { }
                                    submitInput(classes = "button") { value = "Restore Database" }
                                }
                            }

                            div("section") {
                                h2 { +"Notifications Settings" }
                                form(action = "/update-notification-settings", method = FormMethod.post) {
                                    label { +"Email Notifications:" }
                                    select("email-notifications") {
                                        option { +"Enabled" }
                                        option { +"Disabled" }
                                    }
                                    br()
                                    submitInput(classes = "button") { value = "Update Notification Settings" }
                                }
                            }


                            a(href = "/", classes = "back-to-home") { +"Back to Home" }
                        }
                    }
                }
            }

            get("/help") {
                call.respondHtml {
                    WebHead("Help/Support")
                    body {
                        NavigationBar()
                        div("content") {
                            h1 { +"Help/Support" }

                            div("section") {
                                h2 { +"Frequently Asked Questions" }
                                ul {
                                    li { +"How do I manage inventory?" }
                                    li { +"How can I add a new customer?" }
                                    li { +"What to do if I encounter an error?" }
                                }
                            }

                            div("section") {
                                h2 { +"User Guides and Documentation" }
                                ul {
                                    li { a(href = "/docs/inventory") { +"Inventory Management Guide" } }
                                    li { a(href = "/docs/customers") { +"Customer Management Guide" } }
                                    li { a(href = "/docs/reports") { +"Generating Reports Guide" } }
                                }
                            }

                            div("section") {
                                h2 { +"Contact Support" }
                                p { +"Email: support@pharmacy.com" }
                                p { +"Phone: (123) 456-7890" }
                                p { +"Support Hours: Mon-Fri, 9 AM - 5 PM" }
                            }

                            div("section") {
                                h2 { +"Submit Feedback" }
                                form(action = "/submit-feedback", method = FormMethod.post) {
                                    label { +"Name:" }
                                    textInput(name = "name") { required = true }
                                    br()

                                    label { +"Email:" }
                                    textInput(name = "email") { required = true }
                                    br()

                                    label { +"Subject:" }
                                    textInput(name = "subject") { required = true }
                                    br()
//A label for description with text area is required

                                    submitInput(classes = "button") { value = "Submit Feedback" }
                                }

                            }

                            div("section") {
                                h2 { +"System Status" }
                                p { +"All systems are operational." }
                            }

                            a(href = "/", classes = "back-to-home") { +"Back to Home" }
                        }
                    }
                }
            }

            get("style") {
                call.respondText(contentType = ContentType.Text.CSS) {
                    """
                        body {
                            background-color: #f4f4f9;
                            font-family: Arial, sans-serif;
                        }
                        .navbar {
                            overflow: hidden;
                            background-color: blue;
                        }
                        .navbar-list {
                            list-style-type: none;
                            margin: 0;
                            padding: 0;
                        }
                        .navbar-item {
                            float: left;
                        }
                        .navbar-link {
                            display: block;
                            color: white;
                            text-align: center;
                            padding: 14px 20px;
                            text-decoration: none;
                        }
                        .navbar-link:hover {
                            background-color: #575757;
                        }
                        .content {
                            padding: 20px;
                            width:100%;
                            height:1000px;
                                background-color: #ADD8E6;
                                display:flex;
                                flex-direction:column;
                                align-items:center;
                        }
                        .section {
                            margin-top: 20px;
                        }
                        .section h2 {
                            font-size: 1.5em;
                            margin-bottom: 10px;
                        }
                        .section ul {
                            list-style-type: disc;
                            margin-left: 20px;
                        }
                        .back-to-home {
                            display: block;
                            margin-top: 20px;
                            color: #333;
                            text-align: center;
                            padding: 10px;
                            text-decoration: none;
                            font-weight: bold;
                        }
                        .back-to-home:hover {
                            color: #575757;
                        }
                        .hero{
                        width:100%;
                        height:800px;
                        display:flex;
                        flex-direction:column;
                        align-items:center;
                        justify-content:center;
                        gap:15px;
                        background:linear-gradient(0deg, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url("/static/images/hero.jpg");
                        background-postion:center;
                        background-size:cover;
                        object-fit:cover;
                        }
                        .hero h1{
                            font-size:40px;
                            letter-spacing:2px;
                            font-weight:700;
                            font-family:sans-serif;
                        }
                        .Dashboard{
                        width:100%;
                        height:600px;
                        background-color:white;
                        align-items:center;
                        justify-content:center;
                        display:flex;
                        }
                        .Dashboard h1{
                        font-size:40px;
                        letter-spacing:2px;
                        font-weight:700;
                        font-family:sans-serif;
                        }
                        
                    """.trimIndent()
                }
            }
        }
    }.start(wait = true)
}

fun BODY.NavigationBar() = nav("navbar") {
    ul("navbar-list") {
        li("navbar-item") { a(href = "/", classes = "navbar-link") { +"Home" } }
        li("navbar-item") { a(href = "/dashboard", classes = "navbar-link") { +"Dashboard" } }
        li("navbar-item") { a(href = "/inventory", classes = "navbar-link") { +"Inventory Management" } }
        li("navbar-item") { a(href = "/sales", classes = "navbar-link") { +"Sales" } }
        li("navbar-item") { a(href = "/purchasing", classes = "navbar-link") { +"Purchasing" } }
        li("navbar-item") { a(href = "/prescriptions", classes = "navbar-link") { +"Prescriptions" } }
        li("navbar-item") { a(href = "/customers", classes = "navbar-link") { +"Customers" } }
        li("navbar-item") { a(href = "/reports", classes = "navbar-link") { +"Reports" } }
        li("navbar-item") { a(href = "/user-management", classes = "navbar-link") { +"User Management" } }
        li("navbar-item") { a(href = "/settings", classes = "navbar-link") { +"Settings" } }
        li("navbar-item") { a(href = "/help", classes = "navbar-link") { +"Help/Support" } }
    }
}

fun HTML.WebHead(title: String) {
    head {
        title { +title }
        link(rel = "stylesheet", href = "/style")
    }
}
// end point for today
// i love working with kotlin programming language