package intro

import kotlinx.html.li

val latestnewss= listOf(
    Latestnews("Pharmacy Management System version 2.0 released!", "Version 3.0 will be released next two months") ,
    Latestnews("Pharmacy Management System version 2.0 released!", "Version 3.0 will be released next two months"),
    Latestnews("Pharmacy Management System version 2.0 released!", "Version 3.0 will be released next two months"),
    Latestnews("Pharmacy Management System version 2.0 released!", "Version 3.0 will be released next two months"),
    Latestnews("Pharmacy Management System version 2.0 released!", "Version 3.0 will be released next two months"),
    Latestnews("Pharmacy Management System version 2.0 released!", "Version 3.0 will be released next two months"),
)

val FeaturesS= listOf(
    Features("Pharmacy Management System ", "Real-time inventory tracking") ,
    Features("Pharmacy Management System", "Sales and purchase management"),
    Features("Pharmacy Management System ", "Customer and prescription management"),
    Features("Pharmacy Management System ", "Comprehensive reporting"),
    Features("Pharmacy Management System ", "User management and access control"),
)

val DashboardoverviewW= listOf(
    Dashboardoverview("Total products ", 5000) ,
    Dashboardoverview("Total customers", 30),
    Dashboardoverview("Total sales ",  500000000),
    Dashboardoverview("Low level stock alert", 78),
)
