package intro

import kotlinx.html.DIV
import kotlinx.html.li
import kotlinx.html.ul

fun DIV.Latestnewsview(latestnews: Latestnews)=ul{
    li { +"${latestnews.name} , ${latestnews.description}" }
}

fun DIV.Featuresview(features: Features)=ul{
    li { +"${features.name} ,${features.description}" }
}

fun DIV.Dashboardview(Dashboardoverview: Dashboardoverview)=ul{
    li { +"${Dashboardoverview.name} ,${Dashboardoverview.amount}" }
}

